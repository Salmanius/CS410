Raytracer.java
Chris Cochran

To compile:

javac -cp \* Raytracer.java Driver.java DriverLine.java mySphere.java Model.java Vert.java Face.java myLight.java Material.java PPM.java

To run:

java -cp .:\* Raytracer driver.txt output.txt

